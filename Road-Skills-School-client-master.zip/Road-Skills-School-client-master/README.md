# Getting Started with Create React App
This is Driving School Website . developed language is react, html, css, js
i have use here bootstap frameworkd and somewhere material ui.

## authentication system
here only one kinds of login option google.
basically this is firebase login option
note : when you want to login with google popup. try to click 2times.

##live website
https://road-skills-school.web.app/

## Theme design idea
this design i have get from themefores 
you may chekcou out oginal design - hhttp://preview.themeforest.net/item/edlane-driving-school-wordpress-theme/full_screen_preview/23819623

##payment method 
you can pay my stripe paymen(user must be logged in

## Admin Authentication System
and admin can app any service also delete.
he or she can find there shedule daily lesson by calendar (this is extra part)

## Normal User
an normal user can add a review and take a service.
