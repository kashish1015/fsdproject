const firebaseConfig = {
    apiKey: "AIzaSyBRH6EWRW1qUY4IARiPowndpYET5JI7LCs",
    authDomain: "road-skills-school.firebaseapp.com",
    projectId: "road-skills-school",
    storageBucket: "road-skills-school.appspot.com",
    messagingSenderId: "908201245152",
    appId: "1:908201245152:web:e3498477fe9c7c9d3b9385"
  };export default firebaseConfig;